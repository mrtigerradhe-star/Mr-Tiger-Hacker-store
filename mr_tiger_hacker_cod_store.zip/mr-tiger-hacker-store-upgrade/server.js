import express from "express";
import crypto from "node:crypto";
import Database from "better-sqlite3";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(process.env.DB_FILE || "store.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY,
 customer_name TEXT NOT NULL,
 phone TEXT NOT NULL,
 address TEXT NOT NULL,
 payment_method TEXT NOT NULL DEFAULT 'Cash on Delivery',
 payment_status TEXT NOT NULL DEFAULT 'pay_on_delivery',
 order_status TEXT NOT NULL DEFAULT 'pending',
 amount_paise INTEGER NOT NULL,
 currency TEXT NOT NULL DEFAULT 'INR',
 items_json TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`);
const products = [
 {id:1,name:"Everyday Sneakers",category:"Fashion",price:1499,emoji:"👟",desc:"Versatile comfort for everyday outings."},
 {id:2,name:"Wireless Headphones",category:"Tech",price:1999,emoji:"🎧",desc:"Your music, your moment, wherever you go."},
 {id:3,name:"Smart Watch",category:"Tech",price:2499,emoji:"⌚",desc:"A sleek accessory for your daily routine."},
 {id:4,name:"Classic Backpack",category:"Accessories",price:899,emoji:"🎒",desc:"Carry your essentials in style."},
 {id:5,name:"Desk Lamp",category:"Home",price:699,emoji:"💡",desc:"A warm glow for work and study spaces."},
 {id:6,name:"Fitness Bottle",category:"Fitness",price:399,emoji:"🥤",desc:"A reusable companion for active days."},
 {id:7,name:"Minimal Wallet",category:"Accessories",price:499,emoji:"👛",desc:"Keep your daily essentials close."},
 {id:8,name:"Digital Planner",category:"Digital",price:299,emoji:"📒",desc:"A sample digital product for your store."}
];
function adminAuth(req,res,next) {
 const token=req.get("x-admin-token");
 if(!process.env.ADMIN_TOKEN || !token || token!==process.env.ADMIN_TOKEN) return res.status(401).json({error:"Admin token galat hai."});
 next();
}
app.use(express.json({limit:"100kb"}));
app.use(express.static(path.join(__dirname,"public")));
app.get("/api/config",(req,res)=>res.json({storeName:"MR. TIGER HACKER",currency:"INR",paymentMethod:"Cash on Delivery"}));
app.get("/api/products",(req,res)=>res.json(products));
app.post("/api/orders",(req,res)=>{
 try {
  const {customer,items}=req.body||{};
  if(!customer || !String(customer.name||"").trim() || !String(customer.phone||"").trim() || !String(customer.address||"").trim()) return res.status(400).json({error:"Naam, phone aur delivery address zaroori hain."});
  const phone=String(customer.phone).trim();
  if(!/^[0-9+() -]{8,18}$/.test(phone)) return res.status(400).json({error:"Sahi mobile number enter karein."});
  if(!Array.isArray(items)||!items.length||items.length>50) return res.status(400).json({error:"Cart khaali hai ya galat hai."});
  const normalized=[];
  for(const item of items){const product=products.find(p=>p.id===Number(item.id));const qty=Number(item.quantity);if(!product||!Number.isInteger(qty)||qty<1||qty>20)return res.status(400).json({error:"Product ya quantity galat hai."});normalized.push({id:product.id,name:product.name,price:product.price,quantity:qty});}
  const amountPaise=normalized.reduce((sum,item)=>sum+item.price*100*item.quantity,0);
  const localId="MTH-"+crypto.randomBytes(4).toString("hex").toUpperCase();
  db.prepare(`INSERT INTO orders (id,customer_name,phone,address,payment_method,payment_status,order_status,amount_paise,currency,items_json) VALUES (?,?,?,?,?,?,?,?,?,?)`)
   .run(localId,String(customer.name).trim().slice(0,120),phone.slice(0,30),String(customer.address).trim().slice(0,1000),"Cash on Delivery","pay_on_delivery","pending",amountPaise,"INR",JSON.stringify(normalized));
  res.status(201).json({success:true,orderId:localId,amount:amountPaise/100,currency:"INR",paymentMethod:"Cash on Delivery",message:"Order save ho gaya. Delivery par payment karein."});
 } catch(err){console.error("Save COD order failed:",err.message);res.status(500).json({error:"Order save nahi ho saka. Thodi der baad dobara try karein."});}
});
app.get("/api/admin/orders",adminAuth,(req,res)=>{
 const rows=db.prepare("SELECT id,customer_name,phone,address,payment_method,payment_status,order_status,amount_paise,currency,items_json,created_at,updated_at FROM orders ORDER BY created_at DESC LIMIT 500").all();
 res.json(rows.map(r=>({...r,amount:r.amount_paise/100,items:JSON.parse(r.items_json)})));
});
app.patch("/api/admin/orders/:id",adminAuth,(req,res)=>{
 const allowed=["pending","processing","shipped","delivered","cancelled"];
 const status=req.body?.order_status;
 if(!allowed.includes(status))return res.status(400).json({error:"Order status galat hai."});
 const result=db.prepare("UPDATE orders SET order_status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(status,req.params.id);
 if(!result.changes)return res.status(404).json({error:"Order nahi mila."});
 res.json({updated:true});
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`MR. TIGER HACKER COD store running on port ${PORT}`));
