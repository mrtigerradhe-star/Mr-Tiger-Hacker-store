# MR. TIGER HACKER — Cash on Delivery Store

A responsive black-and-gold demo storefront with a server-backed cart checkout, Cash on Delivery orders saved to SQLite, and a token-protected orders dashboard.

## Run locally
1. Install Node.js 20+.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env` and set `ADMIN_TOKEN` to a long random value.
4. Run `npm start`.
5. Open `http://localhost:3000` for the store and `http://localhost:3000/admin.html` for the orders dashboard.

## Deploy from Android
1. Upload the project files to a private or public GitHub repository (do not upload `.env` or `store.db`).
2. Create a Node web service on a host that supports Node.js and persistent disk storage.
3. Build command: `npm install`; start command: `npm start`.
4. Set environment variable `ADMIN_TOKEN` to a long, unique random secret.
5. Attach a persistent disk and set `DB_FILE` to a file path on that disk (for example `/var/data/store.db`, matching the mount path configured with your host). Without persistent storage, orders may be lost when a host restarts or redeploys.
6. Test by placing a sample COD order, then open `/admin.html` and enter your admin token to confirm it is saved.

## Before launch
- The included products/prices are samples. Replace them with products you actually sell and verify all prices, stock, shipping charges, returns/refunds and delivery areas.
- This project stores orders and customer contact/address data. Keep the admin token private, use HTTPS hosting, and only access customer data for order fulfillment.
- Cash on Delivery means payment is collected on delivery; it does not connect to any payment gateway.
- The SQLite database file must be on persistent storage in production. Set `DB_FILE` to a path on the persistent disk.
